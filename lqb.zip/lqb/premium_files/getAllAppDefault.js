




		
		
				stLight.allDefault({cns:{doNotHash:false,hashAddressBar:false,doNotCopy:false},snapsets:{snapsets:false},migration:{version:false},mobileWidget:{mobileWidget:false}});
				
			
		
	

